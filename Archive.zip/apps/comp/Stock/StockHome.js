import React, { Component } from 'react';
import { Text,View } from 'react-native';

export default class StockHome extends Component {
  render() {
    return (
      <View style={{ flex: 1, backgroundColor: '#1ca591' }}>
        <Text>StockHome</Text>
        <Text>StockHome1</Text>
      </View>
    );
  }
}

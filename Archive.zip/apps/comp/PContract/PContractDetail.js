import React, { Component } from 'react';
import { Text,View } from 'react-native';

export default class PContractDetail extends Component {
  render() {
    return (
      <View style={{ flex: 1, backgroundColor: '#2a8c33' }}>
        <Text>PContractDetail</Text>
      </View>
    );
  }
}

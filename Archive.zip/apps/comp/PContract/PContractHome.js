import React, { Component } from 'react';
import { Text,View } from 'react-native';

export default class PContractHome extends Component {
  render() {
    return (
      <View style={{ flex: 1, backgroundColor: 'yellow' }}>
        <Text>PContractHome</Text>
      </View>
    );
  }
}

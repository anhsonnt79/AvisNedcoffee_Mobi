import React, { Component } from 'react';
import { Text,View } from 'react-native';

export default class QualityHome extends Component {
  render() {
    return (
      <View style={{ flex: 1, backgroundColor: '#514c4b' }}>
        <Text>QualityHome</Text>
      </View>
    );
  }
}

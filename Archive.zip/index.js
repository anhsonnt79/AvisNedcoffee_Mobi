import { AppRegistry } from 'react-native';
import App from './apps/App';

AppRegistry.registerComponent('AvisNedcoffee', () => App);
